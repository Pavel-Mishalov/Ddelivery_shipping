<?php

if ( ! defined( 'WPINC' ) ) {
    die;
}

add_filter( 'woocommerce_shipping_calculator_enable_postcode', '__return_false' );
add_filter( 'woocommerce_shipping_calculator_enable_state', '__return_false' );
add_filter( 'woocommerce_shipping_calculator_enable_city', '__return_true' );
/*
 * Check if WooCommerce is active
 */



  function add_ddelivery_shipping_method( $methods ) {
        $methods['ddelivery'] = new WC_DDelivery_Shipping_Method();
      //  $methods[ 'test_method' ] = new WC_Shipping_Test_Method();
        return $methods;
    }
  add_filter( 'woocommerce_shipping_methods', 'add_ddelivery_shipping_method' );


  if ( ! class_exists( 'WC_DDelivery_Shipping_Method' ) ) {
    class WC_DDelivery_Shipping_Method extends WC_Shipping_Method {

    	/**
    	 * Constructor. The instance ID is passed to this.
    	 */
    	public function __construct( $instance_id = 0 ) {
    		$this->id                    = 'ddelviery';
    		$this->instance_id 			     = absint( $instance_id );
    		$this->method_title          = 'Доставка DDelviery';
    		$this->method_description    = 'Дополнительный метод отправки через DDelviery';
    		$this->supports              = array(
    			'shipping-zones',
    			'instance-settings',
    		);
    	  $this->instance_form_fields = array(
      		'enabled' => array(
      			'title' 		=> __( 'Вкл/Выкл' ),
      			'type' 			=> 'checkbox',
      			'label' 		=> 'Включить этот метод доставки',
      			'default' 		=> 'yes',
      		),
      		'title' => array(
      			'title' 		=> 'Название',
      			'type' 			=> 'text',
      			'description' 	=> __( 'Наименование метода, который увидит клиент при оформлении заказа.' ),
      			'default'		=> 'Доставка DDelviery',
      			'desc_tip'		=> true
      		),

          'api_key' => array(
            'title' => 'Ключ API',
            'type' => 'text',
            'description' => 'Ключ API для работы с системой DDelviery',
            'default' => 'a5c284242a4afa3b3dcb6faccc1c393c'
          ),
          'weight' => array(
            'title' => 'Вес (кг)',
            'type' => 'number',
            'description' => 'Вес по умолчанию (если не задан в товаре)',
            'default' => 1
          ),

          'width' => array(
            'title' => 'Ширина (см)',
            'type' => 'number',
            'description' => 'Ширина по умолчанию (если не задан в товаре)',
            'default' => 1
          ),

          'length' => array(
            'title' => 'Длина (см)',
            'type' => 'number',
            'description' => 'Длина по умолчанию (если не задан в товаре)',
            'default' => 1
          ),

          'height' => array(
            'title' => 'Высота (см)',
            'type' => 'number',
            'description' => 'Высота по умолчанию (если не задан в товаре)',
            'default' => 1
          ),
    		);
    		$this->enabled = $this->get_option( 'enabled' );
    		$this->title   = $this->get_option( 'title' );

    		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
    	}

    	/**
    	 * calculate_shipping function.
    	 * @param array $package (default: array())
    	 */
    	public function calculate_shipping( $package = array() ) {

        _log('1....');


        $phash = array();
        foreach ( $package['contents'] as $k=>$p ) {
          $phash[$k] = $p['quantity'];
        }
        $ddl_hash = ( !empty(WC()->customer->__get( 'ddl_hash' )) ) ? WC()->customer->__get( 'ddl_hash' ) : array();
        $check = array_diff_assoc($phash, $ddl_hash);


        if ( !empty($check) ) {
          WC()->customer->__set( 'ddl', Array() );
        }

        $city_to = isset( $_REQUEST['calc_dd_city'] ) ? $_REQUEST['calc_dd_city'] : '';
        if ( $city_to ):
          $ds1 = 0; $ds2 = 0; $ds3 = 0; $weight = 0;
          foreach ( $package['contents'] as $p ) {
            $pkg = $p['data'];
            $ln = ($pkg->get_length()) ? $pkg->get_length() : $this->get_option('length');
            $wd = ($pkg->get_width()) ? $pkg->get_width() : $this->get_option('width');
            $ht = ($pkg->get_height()) ? $pkg->get_height() : $this->get_option('height');
            $wt = ($pkg->get_weight()) ? $pkg->get_weight() : $this->get_option('weight');

            $ds1 = max($ds1, $ln);
            $ds2 = max($ds2, $wd);
            $ds3 = $ds3 + $ht*$p['quantity'];
            $weight = $weight + $wt*$p['quantity'];
          }
          $ds1 = ($package['dimensions']) ? $package['dimensions'] : $this->get_option('length');
          $resp = file_get_contents('http://cabinet.ddelivery.ru/api/v1/'.$this->get_option('api_key').'/calculator.json?type=2&city_to='.$city_to.'&dimension_side1='.$ds1.'&dimension_side2='.$ds2.'&dimension_side3='.$ds3.'&weight='.$weight.'&declared_price='.$package['contents_cost'].'&payment_price='.$package['contents_cost']);
          _Log('>>>>> '.'http://cabinet.ddelivery.ru/api/v1/'.$this->get_option('api_key').'/calculator.json?type=2&city_to='.$city_to.'&dimension_side1='.$ds1.'&dimension_side2='.$ds2.'&dimension_side3='.$ds3.'&weight='.$weight.'&declared_price='.$package['contents_cost'].'&payment_price='.$package['contents_cost']);
          $delivery = json_decode($resp);
          $delivery = $delivery->response;
          WC()->customer->__set( 'ddl_hash', $phash );
          WC()->customer->__set( 'ddl', $delivery );
          $ddl_price = (int)$delivery[0]->total_price;
        endif;

        $ddl = ( !empty(WC()->customer->__get( 'ddl' )) ) ? WC()->customer->__get( 'ddl' ) : false;
        _log('2....');
        if ( $ddl ) {
          foreach ($ddl as $k => $v){
            $rate = array(
              'id' => $this->id.$k,
              'label' => $v->delivery_company_name,
              'cost' => (int)$v->delivery_price + (int)$v->sorting_price + (int)$v->declared_price_fee
            );
            $this->add_rate( $rate );
          }
        }
        _log('99....');
    	}
    }
  }






//
// AJAX STUFF
//



add_action('wp_ajax_ddl_autocomplete', 'ddl_autocomplete');
add_action('wp_ajax_nopriv_ddl_autocomplete', 'ddl_autocomplete');
function ddl_autocomplete() {
  _log('ajax....');
  $resp = file_get_contents('http://cabinet.ddelivery.ru/daemon/?_action=autocomplete&q='.$_POST['q']);
  $data = json_decode($resp);

  $html = '<select name="calc_dd_city" id="calc_city_select">';
  foreach ($data->options as $d) {
    $html .= '<option value="'.$d->_id.'">'.$d->name.' ('.$d->region.')</option>'."\n\r";
  }
  $html .= '</select>';
	echo $html;

	wp_die();
}

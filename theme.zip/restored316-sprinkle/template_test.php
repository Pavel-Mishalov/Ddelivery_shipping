<?php //Template Name: TEST ?>
<?php get_header(); ?>

<?= do_shortcode('[home_slider]'); ?>

<?php get_footer(); ?>
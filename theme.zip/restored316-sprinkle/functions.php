<?php

/* This theme contains intellectual property owned by Restored 316 LLC, including trademarks, copyrights, proprietary information, and other intellectual property. You may not modify, publish, transmit, participate in the transfer or sale of, create derivative works from, distribute, reproduce or perform, or in any way exploit in any format whatsoever any of this theme or intellectual property, in whole or in part, without our prior written consent. */

//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

$logfile = get_stylesheet_directory().'/log.txt';
$preservelog = true;
include_once( get_stylesheet_directory() . '/tmp/00-logger.php' );
include_once( get_stylesheet_directory() . '/woo-shipping.php' );

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'sprinkle_enqueue_scripts_styles' );
function sprinkle_enqueue_scripts_styles() {
	wp_enqueue_script( 'sprinkle-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'dashicons' );
	wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Lato:300,700|Playfair+Display', array() );

	wp_localize_script('jquery', 'ajaxurl', admin_url('admin-ajax.php'));
}

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add new image sizes
add_image_size( 'featured', 460, 300, TRUE );
add_image_size( 'home-middle', 365, 150, TRUE );
add_image_size( 'sidebar', 280, 150, TRUE );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 500,
	'height'          => 150,
	'header-selector' => '.site-title a',
	'header-text'     => false
) );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'sprinkle-gold'         => __( 'Gold', 'sprinkle' ),
	'sprinkle-fashionista'  => __( 'Fashionista', 'sprinkle' ),
	'sprinkle-navy'         => __( 'Navy', 'sprinkle' ),
	'sprinkle-joyful'       => __( 'Joyful', 'sprinkle' ),
	'sprinkle-fucshia '     => __( 'Fucshia', 'sprinkle' ),
	'sprinkle-natural'      => __( 'Natural', 'sprinkle' ),
) );

add_filter('body_class', 'string_body_class');
function string_body_class( $classes ) {
	if ( isset( $_GET['color'] ) ) :
		$classes[] = 'sprinkle-' . sanitize_html_class( $_GET['color'] );
	endif;

	return $classes;
}

//* Reposition the secondary navigation
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//* Hooks home top section widget area to home page
add_action( 'genesis_meta', 'sprinkle_home_featured' );
// *Add widget support for homepage. If no widgets active, display the default loop.
function sprinkle_home_featured() {
	if ( is_front_page() & is_active_sidebar( 'home-slider' ) ) {

		add_action( 'genesis_after_header', 'sprinkle_home_top' );

	}

}

function sprinkle_home_top() {

	echo '<div class="home-top-feature"><div class="wrap">';

    echo '<div class="home-top"><div class="wrap">';

    genesis_widget_area( 'home-slider', array(
		'before' => '<div class="home-slider widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

    genesis_widget_area( 'home-cta', array(
		'before' => '<div class="home-cta widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

    echo '</div></div>';

    echo '<div class="home-middle"><div class="wrap">';

    genesis_widget_area( 'home-middle-left', array(
		'before' => '<div class="home-middle-left widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

    genesis_widget_area( 'home-middle-middle', array(
		'before' => '<div class="home-middle-middle widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

     genesis_widget_area( 'home-middle-right', array(
		'before' => '<div class="home-middle-right widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );

    echo '</div></div>';

    echo '</div></div>';


}

//* Set Genesis Responsive Slider defaults
add_filter( 'genesis_responsive_slider_settings_defaults', 'sprinkle_responsive_slider_defaults' );
function sprinkle_responsive_slider_defaults( $defaults ) {

	$args = array(
		'posts_num'                       => '5',
		'slideshow_height'                => '500',
		'slideshow_title_show'            => 1,
		'slideshow_width'                 => '739',
	);

	$args = wp_parse_args( $args, $defaults );

	return $args;
}

//* Hooks previous and next post
add_action( 'genesis_entry_footer', 'sprinkle_single_post_nav', 9 );
function sprinkle_single_post_nav() {

	if ( is_singular('post' ) ) {

		$prev_post = get_adjacent_post(false, '', true);
		$next_post = get_adjacent_post(false, '', false);
		echo '<div class="prev-next-post-links">';
			previous_post_link( '<div class="previous-post-link" title="Previous Post: ' . $prev_post->post_title . '">%link</div>', '&laquo;' );
			next_post_link( '<div class="next-post-link" title="Next Post: ' . $next_post->post_title . '">%link</div>', '&raquo;' );
		echo '</div>';

	}

}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'sprinkle_remove_comment_form_allowed_tags' );
function sprinkle_remove_comment_form_allowed_tags( $defaults ) {

	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Add search form to navigation
add_filter( 'wp_nav_menu_items', 'sprinkle_prefix_primary_nav_extras', 10, 2 );
function sprinkle_prefix_primary_nav_extras( $menu, $args ) {
	//* Change 'primary' to 'secondary' to add extras to the secondary navigation menu
	if ( 'primary' !== $args->theme_location ) {
		return $menu;
	}

	ob_start();
	get_search_form();
	$search = ob_get_clean();
	$menu .= '<li class="right search">' . $search . '</li>';

	return $menu;
}

//* Customize the credits
add_filter('genesis_footer_creds_text', 'sprinkle_custom_footer_creds_text');
function sprinkle_custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a target="_blank" href="http://restored316designs.com/themes">Sprinkle theme</a> by <a target="_blank" href="http://www.restored316designs.com">Restored 316</a>';
    echo '</p></div>';

}

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Remove Add to Cart on Archives
add_action( 'woocommerce_after_shop_loop_item', 'sprinkle_remove_add_to_cart_buttons', 1 );
function sprinkle_remove_add_to_cart_buttons() {

    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );

}

//* Register widget areas
genesis_register_sidebar( array(
	'id'			=> 'home-slider',
	'name'			=> __( 'Home Slider', 'sprinkle' ),
	'description'	=> __( 'This is the slider on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-cta',
	'name'			=> __( 'Home CTA', 'sprinkle' ),
	'description'	=> __( 'This is the call to action on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-middle-left',
	'name'			=> __( 'Home Middle Left', 'sprinkle' ),
	'description'	=> __( 'This is the call to action on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-middle-middle',
	'name'			=> __( 'Home Middle Middle', 'sprinkle' ),
	'description'	=> __( 'This is the call to action on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-middle-right',
	'name'			=> __( 'Home Middle Right', 'sprinkle' ),
	'description'	=> __( 'This is the call to action on the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-featured',
	'name'			=> __( 'Home Featured', 'sprinkle' ),
	'description'	=> __( 'This is the home featured section of the home page', 'sprinkle' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'category-index',
	'name'			=> __( 'Category Index', 'sprinkle' ),
	'description'	=> __( 'This is the widget space for the category index page template', 'sprinkle' ),
) );

/** Adding custom Favicon */
add_filter( 'genesis_pre_load_favicon', 'custom_favicon' );
function custom_favicon( $favicon_url ) {
	return ''. trailingslashit( get_bloginfo('url') ) .'/wp-content/themes/restored316-sprinkle/images/favicon.ico';
}


//[home_slider]
function home_slider_func( $atts ){?>
	<?php $home_slider = get_field('слайдер',9) ?>

		

	<div class="owl-carousel owl-home-slider">
		<?php foreach ($home_slider as $key => $h_s): ?>
			<a href="<?= $h_s['ссылка'] ?>">
				<img src="<?= $h_s['изображение']['sizes']['slider'] ?>" alt="">
			</a>
		<?php endforeach ?>
	</div>

	<?php
}
add_shortcode( 'home_slider', 'home_slider_func' );

<?php
	
	// $clrspan = 2*60;
	// if (file_exists($logfile)) {
	// 	if (filemtime($logfile) + $crlspan < time() ) {
	// 		file_put_contents($logfile, "");			
	// 	}  
	if (!$preservelog) {  	
		file_put_contents($logfile, "");
	}


	function _log($data) {
		global $logfile;
		file_put_contents($logfile, "".print_r($data, true)."\n", FILE_APPEND);
	}

<?php
/**
 * Shipping Calculator
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/shipping-calculator.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( 'no' === get_option( 'woocommerce_enable_shipping_calc' ) || ! WC()->cart->needs_shipping() ) {
	return;
}

?>

<?php do_action( 'woocommerce_before_shipping_calculator' ); ?>

<form class="woocommerce-shipping-calculator" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">

	<p><a href="#" class="shipping-calculator-button"><?php _e( 'Подсчитать доставку курьером по России', 'woocommerce' ); ?></a></p>

	<section class="shipping-calculator-form" style="display:none;">

		<p class="form-row form-row-wide" id="calc_shipping_country_field">
			<small>	Впишите Ваш город и после этого нажмите кнопку "Найти город". Выбирайте комфортный для Вас способ доставки</small>
			<input  type="hidden" name="calc_shipping_country" id="calc_shipping_country" class="country_to_state" rel="calc_shipping_state" value="RU" disabled="disabled">
		</p>



		<?php if ( apply_filters( 'woocommerce_shipping_calculator_enable_city', false ) ) : ?>

			<p class="form-row form-row-wide" id="calc_shipping_city_field">
				<input type="text" class="input-text" value="<?php // echo esc_attr( WC()->customer->get_shipping_city() ); ?>" placeholder="<?php esc_attr_e( 'Введите ваш город', 'woocommerce' ); ?>" name="calc_shipping_city" id="calc_shipping_city" />
			</p>
			<p><a name="calc_finc_city" value="1" class="button" id="calc_find_cty"><?php _e( 'Найти город', 'woocommerce' ); ?></a></p>
			<div id="calc_dd_resp" style="display:none;">Поиск...</div>


		<?php endif; ?>

		<?php if ( apply_filters( 'woocommerce_shipping_calculator_enable_postcode', true ) ) : ?>

			<p class="form-row form-row-wide" id="calc_shipping_postcode_field">
				<input type="text" class="input-text" value="<?php echo esc_attr( WC()->customer->get_shipping_postcode() ); ?>" placeholder="<?php esc_attr_e( 'Postcode / ZIP', 'woocommerce' ); ?>" name="calc_shipping_postcode" id="calc_shipping_postcode" />
			</p>

		<?php endif; ?>


		<p><button id="calc_calc" type="submit" name="calc_shipping" value="1" class="button" style="display:none;"><?php _e( 'Рассчитать доставку', 'woocommerce' ); ?></button></p>

		<?php wp_nonce_field( 'woocommerce-cart' ); ?>
		<script type="text/javascript" >
		$ = jQuery;
		jQuery(document).on('click', '#calc_find_cty', function(event){
				// console.log('looking up..');
				var data = {
					action: 'ddl_autocomplete',
					q: jQuery('#calc_shipping_city').val()
				};
				jQuery('#calc_dd_resp').fadeIn();
				// с версии 2.8 'ajaxurl' всегда определен в админке
				jQuery.post( ajaxurl, data, function(response) {
					// console.log('Получено с сервера: ' + response);
					jQuery('#calc_dd_resp').html(response).fadeIn();
					jQuery('#calc_calc').fadeIn();
				});
			});

		</script>
	</section>
</form>

<?php do_action( 'woocommerce_after_shipping_calculator' ); ?>
